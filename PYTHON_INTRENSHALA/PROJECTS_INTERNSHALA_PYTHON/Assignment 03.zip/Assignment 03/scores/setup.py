# -*- coding: utf-8 -*-
"""
Created on Tue Mar 26 22:56:51 2019

@author: vaish
"""

from setuptools import setup

setup(name='scores', version='1.0', description='A package to calculate the scores of Players',
url='#',
      author='vaishali',
author_email='vaishsvs12@gmail.com',
      license='VTU',
      packages=['scores'],
zip_safe=False)